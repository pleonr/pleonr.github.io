import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { MercadoPagoConfig, Preference } from 'mercadopago';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;
const accessToken = process.env.MP_ACCESS_TOKEN;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.post('/create-preference', async (req, res) => {
  try {
    if (!accessToken) {
      return res.status(400).json({
        error: 'Defina a variavel de ambiente MP_ACCESS_TOKEN com um token de teste do Mercado Pago.'
      });
    }

    const { title, price } = req.body;
    const numericPrice = Number(price) || 10;

    const client = new MercadoPagoConfig({ accessToken });
    const preference = new Preference(client);

    const result = await preference.create({
      body: {
        items: [
          {
            title: title || 'Produto de teste',
            quantity: 1,
            currency_id: 'BRL',
            unit_price: numericPrice
          }
        ],
        back_urls: {
          success: 'http://localhost:3000/success.html',
          pending: 'http://localhost:3000/pending.html',
          failure: 'http://localhost:3000/failure.html'
        },
        binary_mode: true,
        payment_methods: {
          excluded_payment_methods: [],
          excluded_payment_types: []
        }
      }
    });

    return res.json({
      id: result.id,
      init_point: result.init_point,
      sandbox_init_point: result.sandbox_init_point
    });
  } catch (error) {
    return res.status(500).json({
      error: 'Erro ao criar preferencia',
      details: error.message
    });
  }
});

app.get('/success.html', (_req, res) => {
  res.send('<h1>Pagamento aprovado</h1><p>Fluxo de sandbox concluido.</p><a href="/">Voltar</a>');
});

app.get('/pending.html', (_req, res) => {
  res.send('<h1>Pagamento pendente</h1><p>O pagamento ainda nao foi confirmado.</p><a href="/">Voltar</a>');
});

app.get('/failure.html', (_req, res) => {
  res.send('<h1>Pagamento negado</h1><p>O pagamento nao foi aprovado.</p><a href="/">Voltar</a>');
});

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});