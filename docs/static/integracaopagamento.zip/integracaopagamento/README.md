# Exemplo simples Mercado Pago com Node e Express

Exemplo extremamente simples de integração com o gateway de pagamento do Mercado Pago usando o SDK oficial e o ambiente de sandbox.

O projeto usa JavaScript modules (`type: "module"`) e o servidor roda com `import` nativo.

[Quanto custa vender online no Mercado pago](https://www.mercadopago.com.br/blog/quanto-custa-vender-on-line-com-mercado-pago)

[Mercado pago developers](www.mercadopago.com.br/developers/pt)

## O que faz

- abre uma página HTML bem simples
- envia um formulário para o backend
- cria uma preferencia de pagamento no Mercado Pago
- retorna o link `sandbox_init_point`
- abre o checkout de teste em uma nova aba

## Instalação

```bash
npm install
```

## Configuração

Crie um arquivo `.env` com um token de teste do Mercado Pago:

```bash
MP_ACCESS_TOKEN=TEST-SEU-TOKEN-AQUI
```

Se preferir, você também pode exportar a variável no terminal:

```bash
export MP_ACCESS_TOKEN="TEST-SEU-TOKEN-AQUI"
```

## Executar

```bash
npm start
```

Abra:

```text
http://localhost:3000
```

## Fluxo de teste

1. Preencha o nome do produto e o valor.
2. Clique em gerar link de pagamento.
3. O sistema cria a preferencia no modo sandbox.
4. Abra o `sandbox_init_point` para simular a venda.
5. O retorno usa as rotas de sucesso, pendente e falha definidas em `back_urls`.

## Importante no sandbox

Use contas de teste diferentes para vendedor e comprador.

- O `MP_ACCESS_TOKEN` deve ser de um usuário vendedor de teste.
- O pagamento no checkout deve ser feito com outro usuário de teste, ou em uma janela anônima sem estar logado na conta do vendedor.
- Se o checkout mostrar a mensagem `Uma das partes com as quais você está tentando efetuar o pagamento é de teste`, a conta usada para pagar está incorreta.
- Este exemplo usa apenas o necessário para testar o fluxo.
- Use credenciais de teste do Mercado Pago.
- O retorno do pagamento vai para as rotas simples de sucesso, pendente e falha.
