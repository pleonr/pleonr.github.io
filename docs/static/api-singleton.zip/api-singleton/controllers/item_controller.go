package controllers

import (
	"go-api/models"
	"go-api/services"
	"net/http"

	"github.com/gin-gonic/gin"
)

func GetItems(c *gin.Context) {
	c.JSON(http.StatusOK, services.GetAllItems())
}

func GetItem(c *gin.Context) {
	id := c.Param("id")
	item := services.GetItemByID(id)
	if item == nil {
		c.JSON(http.StatusNotFound, gin.H{"message": "item not found"})
		return
	}
	c.JSON(http.StatusOK, item)
}

func CreateItem(c *gin.Context) {
	var newItem models.Item
	if err := c.ShouldBindJSON(&newItem); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	item := services.AddItem(newItem)
	c.JSON(http.StatusCreated, item)
}

func UpdateItem(c *gin.Context) {
	id := c.Param("id")
	var updatedItem models.Item
	if err := c.ShouldBindJSON(&updatedItem); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	success := services.UpdateItem(id, updatedItem)
	if !success {
		c.JSON(http.StatusNotFound, gin.H{"message": "item not found"})
		return
	}
	c.JSON(http.StatusOK, updatedItem)
}

func DeleteItem(c *gin.Context) {
	id := c.Param("id")
	success := services.DeleteItem(id)
	if !success {
		c.JSON(http.StatusNotFound, gin.H{"message": "item not found"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "item deleted"})
}
