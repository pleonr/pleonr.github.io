package main

import (
	"go-api/config"
	"go-api/models"
	"go-api/routes"
	"log"
)

func main() {
	config.ConnectDatabase()

	migrator := config.DB.Migrator()
	if !migrator.HasTable(&models.Item{}) {
		err := migrator.CreateTable(&models.Item{})
		if err != nil {
			log.Fatalf("Failed to create table: %v", err)
		}
	}

	r := routes.SetupRoutes()
	r.Run(":8080")
}
