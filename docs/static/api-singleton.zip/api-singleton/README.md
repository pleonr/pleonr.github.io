## Qual padrão de projeto está sendo utilizado?

Esse código segue o padrão Singleton com Injeção de Dependência Global (implícita):

| Elemento                             | Descrição                                                                                                                                                                            |
| ------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Singleton**                        | Garante uma única instância da conexão com o banco (`DB *gorm.DB`) para ser usada em toda a aplicação.                                                                               |
| **Encapsulamento da Conexão**        | A função `ConnectDatabase()` centraliza e esconde a lógica de conexão, mantendo o código limpo e DRY (Don't Repeat Yourself).                                                        |
| **Injeção Global (Antipadrão leve)** | O uso da variável global `DB` pode facilitar, mas também pode ser problemático em testes ou aplicações maiores. Uma forma mais limpa seria injetar essa dependência onde necessário. |
