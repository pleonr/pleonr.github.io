package services

import (
	"go-api/config"
	"go-api/models"
)

func GetAllItems() []models.Item {
	var items []models.Item
	config.DB.Find(&items)
	return items
}

func GetItemByID(id string) *models.Item {
	var item models.Item
	result := config.DB.First(&item, id)
	if result.Error != nil {
		return nil
	}
	return &item
}

func AddItem(newItem models.Item) models.Item {
	config.DB.Create(&newItem)
	return newItem
}

func UpdateItem(id string, updated models.Item) bool {
	var item models.Item
	if config.DB.First(&item, id).Error != nil {
		return false
	}
	config.DB.Model(&item).Updates(updated)
	return true
}

func DeleteItem(id string) bool {
	var item models.Item
	if config.DB.First(&item, id).Error != nil {
		return false
	}
	config.DB.Delete(&item)
	return true
}
