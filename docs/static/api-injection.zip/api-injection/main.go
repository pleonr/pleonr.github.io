package main

import (
	"go-api/config"
	"go-api/models"
	"go-api/routes"
	"log"
)

func main() {
	cfg, err := config.LoadConfig()
	if err != nil {
		log.Fatalf("Erro ao carregar configuração: %v", err)
	}

	db, err := config.NewDatabase(cfg)
	if err != nil {
		log.Fatalf("Erro ao conectar ao banco de dados: %v", err)
	}

	migrator := db.Migrator()
	if !migrator.HasTable(&models.Item{}) {
		err := migrator.CreateTable(&models.Item{})
		if err != nil {
			log.Fatalf("Failed to create table: %v", err)
		}
	}

	r := routes.SetupRoutes(db)
	if err := r.Run(":8080"); err != nil {
		log.Fatalf("Erro ao iniciar servidor: %v", err)
	}
}
