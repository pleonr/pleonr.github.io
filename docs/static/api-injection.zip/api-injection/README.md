## Padrão Principal: Dependency Injection

É um padrão onde as dependências (como banco de dados, serviços, etc.) são passadas como parâmetros (geralmente via construtor) em vez de serem instanciadas internamente ou acessadas como variáveis globais.

- A instância do *gorm.DB é criada no main.go e injetada:

  - no serviço (ItemService)
  - no controlador (ItemController)
  - nas rotas via SetupRoutes(db)

Isso melhora a testabilidade e o desacoplamento entre as camadas.

1. Separation of Concerns (SoC)

Cada camada tem responsabilidades bem definidas:

- models: estrutura de dados (entidades)
- services: lógica de negócio
- controllers: lógica de controle e HTTP
- routes: definição das rotas HTTP
- config: configurações do sistema

2. Factory Function (construtores NewXyz)

Usamos funções NewItemService, NewItemController, etc., para encapsular a criação dos objetos com suas dependências já injetadas — isso segue o padrão Factory Function.

3. Clean Architecture (inspirado)

Embora não esteja 100% implementada, a estrutura aproxima-se da Clean Architecture:

- Camadas bem definidas
- Fluxo de dependência unidirecional (de fora para dentro)
- Inversão de dependência via injeção

Nesse exemplo não implementei interfaces entre camadas.

| Vantagem           | Descrição                                                                         |
| ------------------ | --------------------------------------------------------------------------------- |
| **Testabilidade**  | Fácil simular dependências como `gorm.DB` ou `ItemService`.                       |
| **Desacoplamento** | Componentes são menos dependentes entre si.                                       |
| **Flexibilidade**  | Pode trocar banco, serviços ou controladores facilmente.                          |
| **Escalabilidade** | Fica mais fácil adicionar novas funcionalidades com mínima alteração no restante. |
