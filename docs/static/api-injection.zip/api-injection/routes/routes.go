package routes

import (
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"

	"go-api/controllers"
	"go-api/services"
)

func SetupRoutes(db *gorm.DB) *gin.Engine {
	r := gin.Default()

	itemService := services.NewItemService(db)
	itemController := controllers.NewItemController(itemService)

	r.GET("/items", itemController.GetAllItems)
	r.POST("/items", itemController.CreateItem)

	return r
}
