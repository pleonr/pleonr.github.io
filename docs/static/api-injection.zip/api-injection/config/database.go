package config

import (
    "fmt"
    "os"

    "github.com/joho/godotenv"
    "gorm.io/driver/postgres"
    "gorm.io/gorm"
)

type DBConfig struct {
    Host     string
    User     string
    Password string
    DBName   string
    Port     string
    SSLMode  string
}

func LoadConfig() (*DBConfig, error) {
    err := godotenv.Load()
    if err != nil {
        return nil, fmt.Errorf("erro ao carregar o arquivo .env: %w", err)
    }

    config := &DBConfig{
        Host:     os.Getenv("DB_HOST"),
        User:     os.Getenv("DB_USER"),
        Password: os.Getenv("DB_PASSWORD"),
        DBName:   os.Getenv("DB_NAME"),
        Port:     os.Getenv("DB_PORT"),
        SSLMode:  os.Getenv("DB_SSLMODE"),
    }

    return config, nil
}

func NewDatabase(cfg *DBConfig) (*gorm.DB, error) {
    dsn := fmt.Sprintf(
        "host=%s user=%s password=%s dbname=%s port=%s sslmode=%s",
        cfg.Host, cfg.User, cfg.Password, cfg.DBName, cfg.Port, cfg.SSLMode,
    )

    db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
    if err != nil {
        return nil, fmt.Errorf("falha ao conectar ao banco de dados: %w", err)
    }

    return db, nil
}