package controllers

import (
	"net/http"

	"go-api/models"
	"go-api/services"

	"github.com/gin-gonic/gin"
)

type ItemController struct {
	service *services.ItemService
}

func NewItemController(service *services.ItemService) *ItemController {
	return &ItemController{service: service}
}

func (c *ItemController) GetAllItems(ctx *gin.Context) {
	items, err := c.service.GetAllItems()
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": "Erro ao buscar itens"})
		return
	}
	ctx.JSON(http.StatusOK, items)
}

func (c *ItemController) CreateItem(ctx *gin.Context) {
	var item models.Item
	if err := ctx.ShouldBindJSON(&item); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"error": "JSON inválido"})
		return
	}

	if err := c.service.CreateItem(&item); err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"error": "Erro ao criar item"})
		return
	}

	ctx.JSON(http.StatusCreated, item)
}
