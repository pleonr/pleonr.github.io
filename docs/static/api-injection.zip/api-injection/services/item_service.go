package services

import (
	"go-api/models"

	"gorm.io/gorm"
)

type ItemService struct {
	db *gorm.DB
}

func NewItemService(db *gorm.DB) *ItemService {
	return &ItemService{db: db}
}

func (s *ItemService) GetAllItems() ([]models.Item, error) {
	var items []models.Item
	err := s.db.Find(&items).Error
	return items, err
}

func (s *ItemService) CreateItem(item *models.Item) error {
	return s.db.Create(item).Error
}
