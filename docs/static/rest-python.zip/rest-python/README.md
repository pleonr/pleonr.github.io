# FastAPI Users API (SOLID + SQLAlchemy + Postgres) com JWT e Middleware

- API com **FastAPI**
- Implementando **SOLID**
- **SQLAlchemy (ORM)** + Postgres e migrations com Alembic
- **autenticação JWT** via **middleware**
- Testes com pytest
- Swagger
- Makefile

## Recursos
- `users` (CRUD): `id`, `name`, `email`, `birthday`, `password` (hash).
- **Login**: `POST /auth/login` → retorna `{ token, user }`, sem senha.
- **Middleware**: exige `Authorization: Bearer <token>` fora do `/auth/login` e docs.
- **Swagger**: `/docs`, Redoc: `/redoc`.

## Subir com Docker
1. `docker compose up --build`
2. Swagger: http://localhost:8000/docs

## Local sem Docker
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export DB_HOST=localhost DB_PORT=5433 DB_USER=postgres DB_PASSWORD=postgres DB_NAME=usersdb DB_SSLMODE=disable SECRET_KEY=dev-secret
uvicorn app.main:app --reload
```

## Fluxo de uso
```bash
# Criar usuário
curl -X POST http://localhost:8000/users -H "Content-Type: application/json"   -d '{"name":"Ada","email":"ada@upf.br","birthday":"2000-10-12","password":"S3nhaSegura!"}'

# Login
curl -X POST http://localhost:8000/auth/login -H "Content-Type: application/json"   -d '{"email":"ada@upf.br","password":"S3nhaSegura!"}'

# Usar token
curl -H "Authorization: Bearer <TOKEN>" http://localhost:8000/users
```

## Migrações com Alembic
Com `alembic.ini` e `alembic/` já prontos, rode:
```bash
# Usando a URL do settings (recomendado):
export DATABASE_URL="postgresql://postgres:postgres@localhost:5433/usersdb"
alembic upgrade head
# Para criar novas revisões:
alembic revision -m "sua mensagem" --autogenerate
```

## Testes (pytest + httpx/TestClient)

| Nível              | Comando         | O que mostra                          |
| ------------------ | --------------- | ------------------------------------- |
| Básico (padrão)    | `pytest`        | só pontos e resumo final              |
| Verbose            | `pytest -v`     | mostra nome e resultado de cada teste |
| Super Verbose      | `pytest -vv`    | inclui caminho completo e classes     |
| Detalhado com logs | `pytest -vv -s` | mostra `print()` e logs no terminal   |


```bash
docker compose up -d db
pytest -q
pytest --verbose --tb=short --showlocals
```
