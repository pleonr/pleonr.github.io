-- Create test database alongside the main one
-- This runs automatically on first container startup
CREATE DATABASE usersdb_test;
