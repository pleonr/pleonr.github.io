def test_auth_flow_and_protection(client):
    user_payload = {
        "name": "Ada",
        "email": "ada@upf.br",
        "birthday": "2000-10-12",
        "password": "S3nhaSegura!"
    }
    r = client.post("/users", json=user_payload)
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["name"] == "Ada"
    assert "password" not in body

    r = client.get("/users")
    assert r.status_code == 401

    r = client.post("/auth/login", json={"email": "ada@upf.br", "password": "S3nhaSegura!"})
    assert r.status_code == 200, r.text
    login = r.json()
    assert "token" in login
    token = login["token"]

    r = client.get("/users", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200
    users = r.json()
    assert isinstance(users, list)
    assert len(users) >= 1
