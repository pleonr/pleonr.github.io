import os
import pathlib
import pytest

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/usersdb_test")
os.environ["DATABASE_URL"] = DATABASE_URL

from alembic.config import Config
from alembic import command

def _run_migrations(url: str):
    cfg = Config(str(pathlib.Path("alembic.ini").resolve()))
    cfg.set_main_option("sqlalchemy.url", url)
    command.upgrade(cfg, "head")

_run_migrations(DATABASE_URL)

from fastapi.testclient import TestClient
from app.main import app
from app.db.session import engine, get_db
from sqlalchemy.orm import sessionmaker

@pytest.fixture(scope="function")
def db_session():
    connection = engine.connect()
    trans = connection.begin()
    TestingSession = sessionmaker(bind=connection, autocommit=False, autoflush=False)
    session = TestingSession()
    try:
        yield session
    finally:
        session.close()
        trans.rollback()
        connection.close()

@pytest.fixture(autouse=True)
def override_get_db(db_session):
    def _get_db():
        try:
            yield db_session
        finally:
            pass
    app.dependency_overrides[get_db] = _get_db
    yield
    app.dependency_overrides.clear()

@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c
