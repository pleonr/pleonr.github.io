def test_users_crud(client):
    r = client.post("/users", json={
        "name": "Grace",
        "email": "grace@upf.br",
        "birthday": "1990-12-09",
        "password": "SenhaForte123"
    })
    assert r.status_code == 201
    user = r.json()
    uid = user["id"]

    r = client.post("/auth/login", json={"email": "grace@upf.br", "password": "SenhaForte123"})
    assert r.status_code == 200
    token = r.json()["token"]
    headers = {"Authorization": f"Bearer {token}"}

    r = client.get(f"/users/{uid}", headers=headers)
    assert r.status_code == 200

    r = client.patch(f"/users/{uid}", json={"name": "Grace Hopper"}, headers=headers)
    assert r.status_code == 200
    assert r.json()["name"] == "Grace Hopper"

    r = client.get("/users?limit=5", headers=headers)
    assert r.status_code == 200
    assert isinstance(r.json(), list)

    r = client.delete(f"/users/{uid}", headers=headers)
    assert r.status_code == 204
