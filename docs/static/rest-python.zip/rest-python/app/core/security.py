from datetime import datetime, timedelta, timezone
from typing import Optional, Any, Dict
import jwt
from app.core.config import settings

def create_access_token(subject: str | int, expires_minutes: int | None = None, extra_claims: Optional[Dict[str, Any]] = None) -> str:
    expire_delta = timedelta(minutes=expires_minutes if expires_minutes is not None else settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    now = datetime.now(timezone.utc)
    payload: Dict[str, Any] = {"sub": str(subject), "iat": int(now.timestamp()), "exp": int((now + expire_delta).timestamp())}
    if extra_claims:
        payload.update(extra_claims)
    token = jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return token

def decode_token(token: str) -> dict:
    return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
