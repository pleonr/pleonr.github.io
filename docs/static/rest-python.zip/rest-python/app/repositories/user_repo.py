from typing import Sequence
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from app.models.user import User

class UserRepository:
    def __init__(self, db: Session):
        self.db = db

    def create(self, *, name: str, email: str, birthday, password_hash: str) -> User:
        user = User(name=name, email=email, birthday=birthday, password_hash=password_hash)
        self.db.add(user)
        try:
            self.db.commit()
        except IntegrityError:
            self.db.rollback()
            raise
        self.db.refresh(user)
        return user

    def get_by_id(self, user_id: int) -> User | None:
        return self.db.get(User, user_id)

    def get_by_email(self, email: str) -> User | None:
        return self.db.query(User).filter(User.email == email).first()

    def list(self, *, skip: int = 0, limit: int = 100) -> Sequence[User]:
        return self.db.query(User).order_by(User.id).offset(skip).limit(limit).all()

    def update(self, user_id: int, *, name=None, email=None, birthday=None, password_hash=None) -> User | None:
        user = self.get_by_id(user_id)
        if not user:
            return None
        if name is not None:
            user.name = name
        if email is not None:
            user.email = email
        if birthday is not None:
            user.birthday = birthday
        if password_hash is not None:
            user.password_hash = password_hash
        self.db.add(user)
        self.db.commit()
        self.db.refresh(user)
        return user

    def delete(self, user_id: int) -> bool:
        user = self.get_by_id(user_id)
        if not user:
            return False
        self.db.delete(user)
        self.db.commit()
        return True
