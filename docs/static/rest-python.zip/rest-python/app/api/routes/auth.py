from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from passlib.context import CryptContext
from app.db.session import get_db
from app.repositories.user_repo import UserRepository
from app.services.user_service import UserService
from app.core.security import create_access_token
from app.schemas.auth import LoginInput, LoginResponse
from app.schemas.user import UserOut

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
router = APIRouter()

@router.post("/login", response_model=LoginResponse, status_code=status.HTTP_200_OK)
def login(payload: LoginInput, db: Session = Depends(get_db)):
    repo = UserRepository(db)
    svc = UserService(repo)
    user = svc.get_by_email(payload.email)
    if not user or not pwd_context.verify(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token(subject=user.id, extra_claims={"email": user.email})
    user_out = UserOut.model_validate(user, from_attributes=True)
    return LoginResponse(token=token, user=user_out)
