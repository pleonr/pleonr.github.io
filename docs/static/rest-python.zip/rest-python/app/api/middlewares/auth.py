from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from typing import Callable, Awaitable
from app.core.security import decode_token

ALLOWED_PATHS = {"/", "/docs", "/redoc", "/openapi.json"}
PUBLIC_ENDPOINTS = {("POST", "/auth/login"), ("POST", "/users")}

class AuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: Callable[[Request], Awaitable]):
        path = request.url.path
        method = request.method.upper()

        if (
            path in ALLOWED_PATHS
            or path.startswith("/docs")
            or path.startswith("/static/")
            or method == "OPTIONS"
            or (method, path) in PUBLIC_ENDPOINTS
        ):
            return await call_next(request)

        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return JSONResponse({"detail": "Not authenticated"}, status_code=401)

        token = auth.replace("Bearer ", "", 1).strip()
        try:
            payload = decode_token(token)
        except Exception:
            return JSONResponse({"detail": "Invalid or expired token"}, status_code=401)

        request.state.user_id = payload.get("sub")
        request.state.token_payload = payload
        return await call_next(request)
