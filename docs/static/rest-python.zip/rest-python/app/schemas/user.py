from datetime import date, datetime
from typing import Optional
from pydantic import BaseModel, EmailStr, Field

class UserBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=120, examples=["Ada Lovelace"])
    email: EmailStr = Field(..., examples=["ada@upf.br"])
    birthday: Optional[date] = Field(None, examples=["2000-10-12"])

class UserCreate(UserBase):
    password: str = Field(..., min_length=6, max_length=128, examples=["S3nhaSegura!"])

class UserUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=120)
    email: Optional[EmailStr] = None
    birthday: Optional[date] = None
    password: Optional[str] = Field(None, min_length=6, max_length=128)

class UserOut(UserBase):
    id: int
    created_at: datetime   # <- era str
    updated_at: datetime   # <- era str

    model_config = {"from_attributes": True}
