from pydantic import BaseModel, EmailStr, Field
from app.schemas.user import UserOut

class LoginInput(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=6, max_length=128)

class LoginResponse(BaseModel):
    token: str
    user: UserOut
