from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import Engine

class Base(DeclarativeBase):
    pass

def init_models(engine: Engine):
    from app.models.user import User  # noqa: F401
    Base.metadata.create_all(bind=engine)
