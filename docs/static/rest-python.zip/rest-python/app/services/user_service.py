from typing import Sequence
from passlib.context import CryptContext
from sqlalchemy.exc import IntegrityError
from app.repositories.user_repo import UserRepository
from app.schemas.user import UserCreate, UserUpdate
from app.models.user import User

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class UserService:
    def __init__(self, repo: UserRepository):
        self.repo = repo

    def _hash_password(self, password: str) -> str:
        return pwd_context.hash(password)

    def create_user(self, data: UserCreate) -> User:
        password_hash = self._hash_password(data.password)
        try:
            return self.repo.create(name=data.name, email=data.email, birthday=data.birthday, password_hash=password_hash)
        except IntegrityError:
            raise ValueError("Email already exists")

    def list_users(self, *, skip: int = 0, limit: int = 100) -> Sequence[User]:
        return self.repo.list(skip=skip, limit=limit)

    def get_user(self, user_id: int) -> User | None:
        return self.repo.get_by_id(user_id)

    def get_by_email(self, email: str) -> User | None:
        return self.repo.get_by_email(email)

    def update_user(self, user_id: int, data: UserUpdate) -> User | None:
        password_hash = self._hash_password(data.password) if data.password else None
        return self.repo.update(
            user_id,
            name=data.name,
            email=data.email,
            birthday=data.birthday,
            password_hash=password_hash,
        )

    def delete_user(self, user_id: int) -> bool:
        return self.repo.delete(user_id)
