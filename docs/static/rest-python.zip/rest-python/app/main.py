from fastapi import FastAPI
from contextlib import asynccontextmanager

from app.api.routes.users import router as users_router
from app.api.routes.auth import router as auth_router
from app.api.middlewares.auth import AuthMiddleware
from app.db.session import init_db

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(
    title="Users API (SOLID + FastAPI + SQLAlchemy)",
    lifespan=lifespan,
)

app.add_middleware(AuthMiddleware)

app.include_router(users_router, prefix="/users", tags=["users"])
app.include_router(auth_router, prefix="/auth", tags=["auth"])

@app.get("/", tags=["root"])
def read_root():
    return {"status": "ok", "service": "users-api"}
