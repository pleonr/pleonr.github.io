# Gateway

- **Mock API**: recebe qualquer requisição e devolve um JSON com `uuid` e `instance`.
- **Gateway** (super simples):
  - **Load balancer**: round-robin entre `mock1`, `mock2`, `mock3`
  - **Rate limit**: por IP, em memória (`RATE_LIMIT` req por `WINDOW_SEC` segundos)
  - **Circuit breaker** (mínimo viável): abre após `CB_FAIL_THRESHOLD` falhas e espera `CB_COOLDOWN_SEC` antes de testar novamente

## Subir tudo com Docker Compose
```bash
docker compose up --build
```
- Mock services: `mock1:8000`, `mock2:8000`, `mock3:8000` (expostos nas portas 8001/8002/8003 no host)
- Gateway: `localhost:8080`

## Testes
1) Requisição simples (o gateway repassa e você verá a instância que atendeu):
```bash
curl -s http://localhost:8080/hello | jq
```

2) Fazer várias requisições e observar o round-robin (instance alternando):
```bash
for i in {1..6}; do curl -s http://localhost:8080/ping | jq -r '.instance'; done
```

3) Ver rate limit (padrão 30 req em 60s por IP — ajuste `RATE_LIMIT`/`WINDOW_SEC`):
```bash
for i in {1..40}; do curl -s -o /dev/null -w '%{http_code}\n' http://localhost:8080/test; done
# Observe 429 quando exceder
```

4) Circuit breaker (simular falhas): pare um mock e veja o breaker abrir para ele.
```bash
docker stop mock2
```