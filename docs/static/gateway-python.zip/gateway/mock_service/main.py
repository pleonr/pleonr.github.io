from fastapi import FastAPI, Request
from uuid import uuid4
import os
import socket

app = FastAPI(title="Mock API")

INSTANCE_ID = os.getenv("INSTANCE_ID") or socket.gethostname()

@app.api_route("/{path:path}", methods=["GET","POST","PUT","PATCH","DELETE","OPTIONS","HEAD"])
async def echo(path: str, request: Request):
    return {
        "uuid": str(uuid4()),
        "instance": INSTANCE_ID,
        "method": request.method,
        "path": "/" + path if path else "/"
    }
