package main

import (
    "fmt"
    "log"
    "net/http"
)

func handler(w http.ResponseWriter, r *http.Request) {
    fmt.Fprintf(w, "Resposta do backend: %s\n", r.Host)
}

func main() {
    http.HandleFunc("/", handler)
    log.Println("MockAPI ouvindo na porta 8000")
    log.Fatal(http.ListenAndServe(":8000", nil))
}