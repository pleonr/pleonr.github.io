package internal

import (
    "io"
    "net/http"
    "strings"
    "time"
)

func ProxyHandler(w http.ResponseWriter, r *http.Request) {
    ip := GetIP(r.RemoteAddr)
    if !Allow(ip) {
        http.Error(w, "Rate limit excedido", http.StatusTooManyRequests)
        return
    }

    target := GetNextBackend()
    host := strings.TrimPrefix(target, "http://")

    if IsTripped(host) {
        http.Error(w, "Circuit breaker ativado", http.StatusServiceUnavailable)
        return
    }

    proxyURL := target + r.RequestURI

    req, err := http.NewRequest(r.Method, proxyURL, r.Body)
    if err != nil {
        http.Error(w, "Erro ao criar requisição", http.StatusInternalServerError)
        return
    }

    req.Header = r.Header

    client := &http.Client{Timeout: 5 * time.Second}
    resp, err := client.Do(req)
    if err != nil {
        RecordFailure(host)
        http.Error(w, "Erro no backend", http.StatusBadGateway)
        return
    }
    defer resp.Body.Close()

    for k, v := range resp.Header {
        for _, val := range v {
            w.Header().Add(k, val)
        }
    }

    w.WriteHeader(resp.StatusCode)
    _, _ = io.Copy(w, resp.Body)
}