package internal

import "sync"

var (
    backends []string
    index    int
    mu       sync.Mutex
)

func SetBackends(b []string) {
    backends = b
}

func GetNextBackend() string {
    mu.Lock()
    defer mu.Unlock()
    backend := backends[index]
    index = (index + 1) % len(backends)
    return backend
}