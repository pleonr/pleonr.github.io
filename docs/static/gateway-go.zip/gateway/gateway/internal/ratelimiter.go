package internal

import (
    "net"
    "sync"
    "time"
)

type Visitor struct {
    LastSeen time.Time
    Count    int
}

var visitors = make(map[string]*Visitor)
var vMutex sync.Mutex

const (
    rateLimit     = 5
    rateWindow    = 1 * time.Minute
)

func Allow(ip string) bool {
    vMutex.Lock()
    defer vMutex.Unlock()

    visitor, exists := visitors[ip]
    now := time.Now()

    if !exists || now.Sub(visitor.LastSeen) > rateWindow {
        visitors[ip] = &Visitor{LastSeen: now, Count: 1}
        return true
    }

    if visitor.Count >= rateLimit {
        return false
    }

    visitor.Count++
    visitor.LastSeen = now
    return true
}

func GetIP(rAddr string) string {
    ip, _, _ := net.SplitHostPort(rAddr)
    return ip
}