package internal

import (
    "sync"
    "time"
)

type CircuitBreaker struct {
    Failures   int
    LastFailed time.Time
    Tripped    bool
}

var breakers = make(map[string]*CircuitBreaker)
var bMutex sync.Mutex

const (
    failureThreshold = 3
    breakerTimeout   = 15 * time.Second
)

func RecordFailure(host string) {
    bMutex.Lock()
    defer bMutex.Unlock()

    cb, exists := breakers[host]
    if !exists {
        cb = &CircuitBreaker{}
        breakers[host] = cb
    }

    cb.Failures++
    cb.LastFailed = time.Now()
    if cb.Failures >= failureThreshold {
        cb.Tripped = true
    }
}

func IsTripped(host string) bool {
    bMutex.Lock()
    defer bMutex.Unlock()

    cb, exists := breakers[host]
    if !exists {
        return false
    }

    if cb.Tripped && time.Since(cb.LastFailed) > breakerTimeout {
        cb.Tripped = false
        cb.Failures = 0
        return false
    }

    return cb.Tripped
}