package main

import (
    "fmt"
    "log"
    "net/http"
    "os"
    "strings"

    "gateway/internal"
)

func main() {
    raw := os.Getenv("BACKENDS")
    if raw == "" {
        log.Fatal("BACKENDS não definido")
    }
    internal.SetBackends(strings.Split(raw, ","))

    mux := http.NewServeMux()
    mux.HandleFunc("/health", internal.HealthHandler)
    mux.HandleFunc("/", internal.ProxyHandler)

    fmt.Println("Gateway ouvindo na porta 8000")
    log.Fatal(http.ListenAndServe(":8000", mux))
}