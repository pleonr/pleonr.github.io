import axios from 'axios'

export interface Transaction {
  id: string
  payer: string
  payee: string
  amount: number
  currency: string
  description?: string
  meta?: Record<string, any>
}

export interface SignRequest {
  username: string
  password: string
  transaction: Transaction
}
export interface SignResponse {
  signedDocumentXml: string
}

const baseURL: string = (globalThis as any).process?.env?.NEXT_PUBLIC_API_BASE ?? 'http://localhost:4000'
export const api: ReturnType<typeof axios.create> = axios.create({ baseURL, timeout: 15000 })

export async function signDocument(payload: SignRequest): Promise<SignResponse> {
  const { data } = await api.post<SignResponse>('/api/sign', payload)
  return data
}
