import { useRouter } from 'next/router';

export default function Navbar(): JSX.Element {
  const router = useRouter();
  return (
    <nav className="navbar">
      <button onClick={() => router.push('/')}>Home</button>
      <button onClick={() => router.push('/sign')}>Documentos</button>
      <a href="https://www.w3.org/TR/SOAP/" target="_blank" rel="noreferrer">
        <button>SOAP</button>
      </a>
    </nav>
  );
}
