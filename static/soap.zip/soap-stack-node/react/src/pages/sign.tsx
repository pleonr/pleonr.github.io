import { useState, useRef, FormEvent } from 'react'
import Navbar from '@/components/Navbar'
import { signDocument as signDocSvc, type Transaction, type SignResponse } from '@/services/api'

type Status = 'PROCESSADO' | 'AGUARDANDO' | 'REJEITADO' | null
type RowState = { tx: Transaction; sending: boolean; error?: string | null; signedXml?: string | null; status: Status }

const initialTxs: Transaction[] = [
  { id: 'tx-001', payer: 'Alice', payee: 'Bob', amount: 199.9, currency: 'BRL', description: 'Compra laboratório' },
  { id: 'tx-002', payer: 'Carol', payee: 'Dave', amount: 75.5, currency: 'BRL', description: 'Serviço de nuvem' },
  { id: 'tx-003', payer: 'Eve', payee: 'Mallory', amount: 10.0, currency: 'BRL', description: 'Café' },
]

export default function SignPage(): JSX.Element {
  const [rows, setRows] = useState<RowState[]>(
    initialTxs.map(tx => ({ tx, sending: false, error: null, signedXml: null, status: null }))
  )
  const [showModal, setShowModal] = useState<boolean>(false)
  const [modalTx, setModalTx] = useState<Transaction>({ id: '', payer: '', payee: '', amount: 0, currency: 'BRL', description: '' })
  const [username, setUsername] = useState<string>('admin')
  const [password, setPassword] = useState<string>('secret')
  const downloadRef = useRef<HTMLButtonElement | null>(null)

  function openModal() { setModalTx({ id: '', payer: '', payee: '', amount: 0, currency: 'BRL', description: '' }); setShowModal(true) }
  function closeModal() { setShowModal(false) }

  function addTx(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (!modalTx.id) return
    setRows(prev => [{ tx: modalTx, sending: false, error: null, signedXml: null, status: null }, ...prev])
    setShowModal(false)
  }

  function parseStatusFromSoap(xml: string): Status {
    try {
      if (typeof window !== 'undefined' && 'DOMParser' in window) {
        const parser = new DOMParser()
        const doc = parser.parseFromString(xml, 'application/xml')
        const ns = 'http://example.com/soap/SignerService'
        let node: Element | null = null

        try {
          node = doc.getElementsByTagNameNS(ns, 'Status')?.[0] ?? null
        } catch { }

        if (!node) node = doc.querySelector('tns\\:Status, Status') as Element | null

        const text = node?.textContent?.trim().toUpperCase() || null
        if (text === 'PROCESSADO' || text === 'AGUARDANDO' || text === 'REJEITADO') return text
        return null
      }
    } catch { }

    const m = xml.match(/<(?:\w+:)?Status>([^<]+)<\/(?:\w+:)?Status>/i)
    const val = m?.[1]?.trim().toUpperCase() || null
    if (val === 'PROCESSADO' || val === 'AGUARDANDO' || val === 'REJEITADO') return val
    return null
  }

  function StatusBadge({ status }: { status: Status }) {
    if (!status) return <span style={{ color: '#6b7a90' }}>—</span>
    const base: React.CSSProperties = {
      fontSize: 12, padding: '3px 8px', borderRadius: 999, display: 'inline-block', fontWeight: 600
    }
    if (status === 'PROCESSADO') {
      return <span style={{ ...base, background: '#173d2b', border: '1px solid #2c6e49', color: '#9be5b0' }}>Processado</span>
    }
    if (status === 'AGUARDANDO') {
      return <span style={{ ...base, background: '#3b3617', border: '1px solid #9d8b2f', color: '#f6e27b' }}>Aguardando</span>
    }
    return <span style={{ ...base, background: '#3d1717', border: '1px solid #7a2e2e', color: '#ffb4b4' }}>Rejeitado</span>
  }

  async function sendTx(idx: number) {
    setRows(prev => prev.map((r, i) => i === idx ? { ...r, sending: true, error: null, signedXml: null, status: null } : r))
    try {
      const r = rows[idx]
      const data: SignResponse = await signDocSvc({ username, password, transaction: r.tx })

      const xml = (data as any).signedDocumentXml ?? (typeof data === 'string' ? data : '')
      const status = xml ? parseStatusFromSoap(xml) : null

      setRows(prev => prev.map((row, i) =>
        i === idx ? { ...row, sending: false, signedXml: xml || null, status } : row
      ))
      setTimeout(() => downloadRef.current?.focus(), 50)
    } catch (err: any) {
      const msg = err?.response?.data?.message || err.message || 'Erro ao enviar transação'
      setRows(prev => prev.map((row, i) => i === idx ? { ...row, sending: false, error: msg, status: null } : row))
    }
  }

  function download(xml: string, id: string) {
    const blob = new Blob([xml], { type: 'application/xml;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = `signed_${id}.xml`; document.body.appendChild(a)
    a.click(); a.remove(); URL.revokeObjectURL(url)
  }

  return (
    <div>
      <Navbar />
      <main className="container">
        <div className="card">
          <h1>Transações</h1>
          <div style={{ display: 'flex', gap: 12, margin: '12px 0' }}>
            <button className="btn" onClick={openModal}>Nova transação</button>
            <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
              <input className="input" placeholder="Usuário" value={username} onChange={e=>setUsername(e.target.value)} style={{ width: 160 }} />
              <input className="input" type="password" placeholder="Senha" value={password} onChange={e=>setPassword(e.target.value)} style={{ width: 160 }} />
            </div>
          </div>

          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={{ textAlign: 'left', padding: 8 }}>ID</th>
                  <th style={{ textAlign: 'left', padding: 8 }}>Pagador</th>
                  <th style={{ textAlign: 'left', padding: 8 }}>Recebedor</th>
                  <th style={{ textAlign: 'right', padding: 8 }}>Valor</th>
                  <th style={{ textAlign: 'center', padding: 8 }}>Moeda</th>
                  <th style={{ textAlign: 'left', padding: 8 }}>Descrição</th>
                  <th style={{ textAlign: 'center', padding: 8 }}>Status</th>
                  <th style={{ textAlign: 'center', padding: 8 }}>Ações</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, idx) => (
                  <tr key={r.tx.id} style={{ borderTop: '1px solid #243041' }}>
                    <td style={{ padding: 8 }}>{r.tx.id}</td>
                    <td style={{ padding: 8 }}>{r.tx.payer}</td>
                    <td style={{ padding: 8 }}>{r.tx.payee}</td>
                    <td style={{ padding: 8, textAlign: 'right' }}>{r.tx.amount.toFixed(2)}</td>
                    <td style={{ padding: 8, textAlign: 'center' }}>{r.tx.currency}</td>
                    <td style={{ padding: 8 }}>{r.tx.description || '-'}</td>
                    <td style={{ padding: 8, textAlign: 'center' }}>
                      <StatusBadge status={r.status} />
                    </td>
                    <td style={{ padding: 8, textAlign: 'center' }}>
                      {!r.signedXml ? (
                        <button className="btn" disabled={r.sending} onClick={() => sendTx(idx)}>
                          {r.sending ? 'Enviando...' : 'Enviar'}
                        </button>
                      ) : (
                        <button className="btn" ref={downloadRef} onClick={() => download(r.signedXml!, r.tx.id)}>
                          Comprovante
                        </button>
                      )}
                      {r.error && <div style={{ color: '#ffb4b4', marginTop: 6, maxWidth: 260 }}>{r.error}</div>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {showModal && (
        <div style={modalBackdrop}>
          <div style={modalCard} role="dialog" aria-modal="true">
            <h2>Nova transação</h2>
            <form onSubmit={addTx}>
              <label>ID</label>
              <input className="input" value={modalTx.id} onChange={e=>setModalTx({ ...modalTx, id: e.target.value })} required />
              <label>Pagador</label>
              <input className="input" value={modalTx.payer} onChange={e=>setModalTx({ ...modalTx, payer: e.target.value })} required />
              <label>Recebedor</label>
              <input className="input" value={modalTx.payee} onChange={e=>setModalTx({ ...modalTx, payee: e.target.value })} required />
              <label>Valor</label>
              <input className="input" type="number" step="0.01" value={modalTx.amount} onChange={e=>setModalTx({ ...modalTx, amount: Number(e.target.value) })} required />
              <label>Moeda</label>
              <input className="input" value={modalTx.currency} onChange={e=>setModalTx({ ...modalTx, currency: e.target.value })} required />
              <label>Descrição</label>
              <input className="input" value={modalTx.description || ''} onChange={e=>setModalTx({ ...modalTx, description: e.target.value })} />
              <div style={{ display: 'flex', gap: 12, marginTop: 12, justifyContent: 'flex-end' }}>
                <button className="btn" type="button" onClick={closeModal}>Cancelar</button>
                <button className="btn" type="submit">Adicionar</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

const modalBackdrop: React.CSSProperties = {
  position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)',
  display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16, zIndex: 50
}
const modalCard: React.CSSProperties = {
  background: '#0d1526', border: '1px solid #243041', borderRadius: 16, padding: 20, width: '100%', maxWidth: 520
}
