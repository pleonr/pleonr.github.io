import Navbar from '@/components/Navbar'

export default function Home(): JSX.Element {
  return (
    <div>
      <Navbar />
      <main className="container">
        <div className="card">
          <h1>API SOAP — Assinatura de Documentos XML</h1>
          <p className="small">Microserviços</p>
          <h2>Como funciona neste projeto?</h2>
          <ol>
            <li>Serviço SOAP expõe <code>SignDocument(username, password, documentXml)</code>.</li>
            <li>REST (Express) monta o envelope SOAP + WS-Security e chama o SOAP.</li>
            <li>Next.js consome o REST e oferece o download do XML assinado.</li>
          </ol>
        </div>
      </main>
    </div>
  )
}
