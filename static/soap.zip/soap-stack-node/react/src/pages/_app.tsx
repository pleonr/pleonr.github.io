import type { AppProps } from 'next/app'
// @ts-ignore: allow importing CSS without a module declaration
import '../styles/globals.css'

export default function App({ Component, pageProps }: AppProps) {
  return <Component {...pageProps} />
}
