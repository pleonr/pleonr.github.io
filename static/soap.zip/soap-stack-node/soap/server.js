import express from 'express';
import bodyParser from 'body-parser';
import morgan from 'morgan';
import fs from 'fs';
import path from 'path';
import https from 'https';
import { create } from 'xmlbuilder2';

const app = express();
app.use(morgan('dev'));
app.use(bodyParser.text({ type: ['text/xml', 'application/xml', 'application/soap+xml'] }));

// Certificados autoassinados
const CERT_DIR = path.join(process.cwd(), '..', 'certs', 'server');
const key = fs.readFileSync(path.join(CERT_DIR, 'server.key.pem'));
const cert = fs.readFileSync(path.join(CERT_DIR, 'server.cert.pem'));

app.get('/wsdl', (req, res) => {
  const baseUrl = `https://${req.hostname}:${process.env.PORT || 8443}`;
  const wsdl = create({ version: '1.0' })
    .ele('definitions', {
      'xmlns:wsdl': 'http://schemas.xmlsoap.org/wsdl/',
      'xmlns:xs':   'http://www.w3.org/2001/XMLSchema',
      'xmlns:soap': 'http://schemas.xmlsoap.org/soap/envelope/',
      'xmlns:tns': 'http://example.com/soap/SignerService',
      'targetNamespace': 'http://seu.namespace/aqui'
    })
      // xs:types ...
      // wsdl:message (HealthCheckRequest/Response, etc.)
      // wsdl:portType (operations)
      // wsdl:binding (SOAP 1.1/1.2, literal)
      // wsdl:service (soap:address -> `${baseUrl}/soap`)
    .end({ prettyPrint: true });

  res.setHeader('Content-Type', 'text/xml; charset=utf-8');
  res.status(200).send(wsdl);
});

app.post('/wsdl', (req, res) => {
  const receivedXml = req.body || '';
  const now = new Date().toISOString();

  const soapResponse = create({ version: '1.0', encoding: 'UTF-8' })
    .ele('soap:Envelope', {
      'xmlns:soap': 'http://schemas.xmlsoap.org/soap/envelope/',
      'xmlns:tns': 'http://example.com/soap/SignerService'
    })
      .ele('soap:Header').up()
      .ele('soap:Body')
        .ele('tns:SignTransactionResponse')
          .ele('tns:Status').txt('PROCESSADO').up()
          .ele('tns:ProcessedAt').txt(now).up()
          .ele('tns:OriginalPayload').dat(receivedXml).up()
        .up()
      .up()
    .up()
    .end({ prettyPrint: true });

  res.set('Content-Type', 'text/xml; charset=utf-8');
  return res.status(200).send(soapResponse);
});

const PORT = process.env.PORT || 8443;

https.createServer({ key, cert }, app).listen(PORT, () => {
  console.log(`SOAP HTTPS ouvindo em https://localhost:${PORT}/wsdl`);
});
