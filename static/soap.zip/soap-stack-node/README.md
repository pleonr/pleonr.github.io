# SOAP em microserviços

Esse projeto simula um envio de "pagamentos para um gateway de pagamentos." O projeto consiste em:

- Frontend com REACT e nextjs
- API REST para comunicação com SOAP
- API SOAP

## Passo a Passo

Instale a lib OpenSSL para geração dos certificados simulando um HTTPS

```bash
sudo apt install openssl make
```

Então execute o script `make certs` para criar os certificados em suas pastas.


Após isso apenas execute o make para o serviço que você quer executar.
- `make rest`
- `make soap`
- `make react`