#!/usr/bin/env bash
set -euo pipefail

# Gera uma CA (Certificate Authority) e um certificado de servidor (localhost) para desenvolvimento.

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

mkdir -p ca server

# 1) CA (chave e certificado)
if [ ! -f ca/ca.key.pem ]; then
  openssl genrsa -out ca/ca.key.pem 4096
fi

openssl req -x509 -new -nodes -key ca/ca.key.pem -sha256 -days 3650 -out ca/ca.cert.pem -subj "/C=BR/ST=SP/L=SaoPaulo/O=Demo/OU=Dev/CN=Demo-Local-CA"

# 2) Server key e CSR
openssl genrsa -out server/server.key.pem 2048
openssl req -new -key server/server.key.pem -out server/server.csr.pem -subj "/C=BR/ST=SP/L=SaoPaulo/O=Demo/OU=Dev/CN=localhost"

# 3) Extensões para SubjectAltName
cat > server/server.ext <<EOF
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
keyUsage = digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
subjectAltName = @alt_names

[alt_names]
DNS.1 = localhost
IP.1 = 127.0.0.1
EOF

# 4) Assina o certificado do servidor com a CA
openssl x509 -req -in server/server.csr.pem -CA ca/ca.cert.pem -CAkey ca/ca.key.pem -CAcreateserial -out server/server.cert.pem -days 825 -sha256 -extfile server/server.ext

echo "Certificados gerados em:"
echo "  CA:      $(pwd)/ca/ca.cert.pem (instale como autoridade confiável apenas para DEV)"
echo "  Server:  $(pwd)/server/server.cert.pem e server/server.key.pem"
